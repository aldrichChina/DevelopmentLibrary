# SQL Manager 2005 Lite for MySQL 3.7.0.1
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : tour


SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE `tour`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

#
# Structure for the `message` table : 
#

CREATE TABLE `message` (
  `_id` int(11) NOT NULL auto_increment,
  `message` varchar(255) default NULL,
  `userName` varchar(255) default NULL,
  PRIMARY KEY  (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

#
# Structure for the `user` table : 
#

CREATE TABLE `user` (
  `_id` int(11) NOT NULL auto_increment,
  `money` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `phone` varchar(255) default NULL,
  `myName` varchar(255) default NULL,
  `userName` varchar(255) default NULL,
  PRIMARY KEY  (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Data for the `message` table  (LIMIT 0,500)
#

INSERT INTO `message` (`_id`, `message`, `userName`) VALUES 
  (1,'hello word','bbb'),
  (2,'it is good.','wang'),
  (3,'i will come again.','wang'),
  (4,'i like there','wang'),
  (5,'ok','wang'),
  (6,'yes','wang');

COMMIT;

#
# Data for the `user` table  (LIMIT 0,500)
#

INSERT INTO `user` (`_id`, `money`, `password`, `phone`, `myName`, `userName`) VALUES 
  (1,NULL,'11','11235656','aa','aa'),
  (2,NULL,'11','11235656','aa','aa'),
  (3,'9796.0','111','6547657754','wo shi lao wang','bbb'),
  (4,NULL,'123','123','123','123'),
  (5,'8882.0','123456','18734903493','lisan','wang');

COMMIT;

