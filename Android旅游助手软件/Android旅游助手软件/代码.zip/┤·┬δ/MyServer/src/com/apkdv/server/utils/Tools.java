package com.apkdv.server.utils;

import com.google.gson.Gson;

public class Tools {
	public static Gson gson = new Gson();
}
