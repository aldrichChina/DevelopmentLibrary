package com.wly.afinal_db;

import net.tsz.afinal.annotation.sqlite.Table;

@Table(name="Test_User")
public class User {

	private int id;
	private String name;
	private int age;
	
	//必须包含这个默认的构造方法，否则在进行数据查找时，会报错
	public User() {
		
	}
	
	//这个构造方法是可以正常使用的，说明id是主键，且是自增长的
	public User(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
