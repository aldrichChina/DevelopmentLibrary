package com.wly.afinal_db;

import java.util.List;

import net.tsz.afinal.FinalActivity;
import net.tsz.afinal.FinalDb;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.wly.afinal.tools.Loger;
import com.wly.afinallearn.R;


public class MainDBActivity extends FinalActivity {
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.main_db);
		
		final EditText searchKeyET = (EditText)findViewById(R.id.db_et_search_key);
		final TextView searchResultTV = (TextView)findViewById(R.id.db_tv_searchresult);
		//建表
		findViewById(R.id.constructdb).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//下面语句创建的数据库名称，为默认的afinal.db
				//FinalDb db = FinalDb.create(MainDBActivity.this);
				
				//下面语句会创建指定名称的数据库
				FinalDb db = FinalDb.create(MainDBActivity.this, "user.db");
				
				Loger.i("DB", "Construct DB");
			}
		});
		
		//插入数据
		findViewById(R.id.insertdata).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//FinalDb是单例的，create()方法会返回FinalDb的单例对象，即不会重复创建
				FinalDb db = FinalDb.create(MainDBActivity.this, "user.db");
				User user = new User("AoTuMan", 3);
				//这里直接调用save，会自动创建一个名为报名_实体类名的数据表，这里的是com_wly_afinal_db_User
				db.save(user);
				Loger.i("DB", "Save data");
			}
		});
		
		//删除数据
		
		findViewById(R.id.db_btn_delete).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				//拿到FinalDb对象引用
				FinalDb db = FinalDb.create(MainDBActivity.this, "user.db");
				
//				db.delete(user); //根据对象主键进行删除				
//				db.deleteById(user, 1); //根据主键删除数据
//				db.deleteByWhere(User.class, "name=AoTuMan"); //自定义where条件删除
				db.deleteAll(User.class); //删除Bean对应的数据表中的所有数据

				
			}
		});
		
		findViewById(R.id.db_btn_search).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String searchKey = searchKeyET.getText().toString();
				
				//拿到FinalDb对象引用
				FinalDb db = FinalDb.create(MainDBActivity.this, "user.db");
				
				//注意这里的"where"语句参数是没有where关键字的
				List<User> resultList = db.findAllByWhere(User.class, " name=\"" + searchKey + "\"");
//				List<User> resultList = db.findAll(User.class); //查找指定Bean的所有数据记录
				StringBuilder _sb = new StringBuilder();
				for(int i=0;i<resultList.size();i++) {
					_sb.append("id:" + resultList.get(i).getId()
							+ " name:" + resultList.get(i).getName()
							+ " age:" + resultList.get(i).getAge());
				}
				
				searchResultTV.setText(_sb.toString());
			}
		});
	}


}
