package com.wly.afinal.tools;

import android.util.Log;

public class Loger {

	private static boolean debug = true;
	
	public static void e(String tag,String error) {
		if(debug) {
			Log.e(tag, error);
		}
	}
	
	public static void i(String tag,String info) {
		if(debug) {
			Log.i(tag, info);
		}
	}
}
